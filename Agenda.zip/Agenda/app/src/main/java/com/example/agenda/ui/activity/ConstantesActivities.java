package com.example.agenda.ui.activity;

@SuppressWarnings("WeakerAccess")
public interface ConstantesActivities {
   String CHAVE_ALUNO = "aluno";
   String TITULO_APPBAR_NOVO_ALUNO = "Novo aluno";
   String TITULO_APPBAR_EDITA_ALUNO = "Edita aluno";
    String MASCARA_TELEFONE = "(##) #####-####";
}
